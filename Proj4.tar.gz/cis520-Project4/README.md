# cis520-Project4

Compiling pthreads
gcc -lpthread Pthreads.c

Compiling openMP
gcc -fopenmp OpenMP.c

